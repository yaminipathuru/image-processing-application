import os
import cv2
import numpy as np
from django.shortcuts import render
from django.conf import settings
import uuid

def upload_image(request):
    if request.method == "POST" and request.FILES.get("image"):
        img_file = request.FILES["image"]
        filename = img_file.name
        save_path = os.path.join(settings.MEDIA_ROOT, filename)

        # Save uploaded image
        with open(save_path, "wb") as f:
            for chunk in img_file.chunks():
                f.write(chunk)

        return render(request, "editor.html", {
            "original_image": settings.MEDIA_URL + filename,
            "processed_image": None,
            "filename": filename
        })
    return render(request, "upload.html")

def process_image(request):
    if request.method == "POST":
        filename = request.POST.get("filename")
        operation = request.POST.get("operation")

        original_path = os.path.join(settings.MEDIA_ROOT, filename)
        img = cv2.imread(original_path)

        if img is None:
            return render(request, "editor.html", {"error": "Image not found!"})

        # --- 1. Grayscale ---
        if operation == "gray":
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

        # --- 2. Blur ---
        elif operation == "blur":
            img = cv2.blur(img, (10,10))

        # --- 3. Edge Detection ---
        elif operation == "edge":
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            img = cv2.Canny(gray, 50, 150)
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

        # --- 4. Sharpen ---
        elif operation == "sharpen":
            kernel = np.array([[0,-1,0],[-1,5,-1],[0,-1,0]])
            img = cv2.filter2D(img, -1, kernel)

        # --- 5. Emboss ---
        elif operation == "emboss":
            kernel = np.array([[ -2,-1,0],[-1,1,1],[0,1,2]])
            img = cv2.filter2D(img, -1, kernel)

        # --- 6/7. Brightness ---
        elif operation == "brightness_inc":
            img = cv2.convertScaleAbs(img, alpha=1, beta=50)
        elif operation == "brightness_dec":
            img = cv2.convertScaleAbs(img, alpha=1, beta=-50)

        # --- 8/9. Contrast ---
        elif operation == "contrast_inc":
            img = cv2.convertScaleAbs(img, alpha=1.5, beta=0)
        elif operation == "contrast_dec":
            img = cv2.convertScaleAbs(img, alpha=0.7, beta=0)

        # --- 10. Threshold ---
        elif operation == "threshold":
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
            img = cv2.cvtColor(thresh, cv2.COLOR_GRAY2BGR)

        # --- 11. Invert ---
        elif operation == "invert":
            img = cv2.bitwise_not(img)

        # --- 12. Sepia ---
        elif operation == "sepia":
            kernel = np.array([[0.272,0.534,0.131],
                               [0.349,0.686,0.168],
                               [0.393,0.769,0.189]])
            img = cv2.transform(img, kernel)
            img = np.clip(img,0,255).astype(np.uint8)

        # --- 13. Cartoon ---
        elif operation == "cartoon":
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            gray = cv2.medianBlur(gray,5)
            edges = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_MEAN_C,
                                          cv2.THRESH_BINARY,9,9)
            color = cv2.bilateralFilter(img, 9, 250, 250)
            img = cv2.bitwise_and(color, color, mask=edges)

        # --- 14. Pencil Sketch ---
        elif operation == "sketch":
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            inv = cv2.bitwise_not(gray)
            blur = cv2.GaussianBlur(inv, (21,21), 0)
            sketch = cv2.divide(gray, 255-blur, scale=256)
            img = cv2.cvtColor(sketch, cv2.COLOR_GRAY2BGR)

        # --- 15/16. Rotate ---
        elif operation == "rotate_left":
            img = cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
        elif operation == "rotate_right":
            img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)

        # --- 17/18. Flip ---
        elif operation == "flip_horizontal":
            img = cv2.flip(img, 1)
        elif operation == "flip_vertical":
            img = cv2.flip(img, 0)

        # --- 19. Gaussian Blur ---
        elif operation == "gaussian_blur":
            img = cv2.GaussianBlur(img, (15,15), 0)

        # --- 20. Median Blur ---
        elif operation == "median_blur":
            img = cv2.medianBlur(img, 15)

        # --- Save processed image as a NEW file ---
        processed_filename = f"processed_{uuid.uuid4().hex[:8]}_{filename}"
        processed_path = os.path.join(settings.MEDIA_ROOT, processed_filename)
        cv2.imwrite(processed_path, img)

        # --- Render template with original and processed images ---
        return render(request, "editor.html", {
            "original_image": settings.MEDIA_URL + filename,
            "processed_image": settings.MEDIA_URL + processed_filename,
            "filename": filename
        })
